module.exports = window.renderMathInElement
