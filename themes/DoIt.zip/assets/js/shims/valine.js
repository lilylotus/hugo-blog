module.exports = window.Valine
