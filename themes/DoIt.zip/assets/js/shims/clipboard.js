export default window.ClipboardJS
