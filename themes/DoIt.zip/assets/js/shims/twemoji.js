module.exports = window.twemoji
