module.exports = window.cookieconsent
