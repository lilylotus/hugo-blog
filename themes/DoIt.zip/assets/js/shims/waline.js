module.exports = window.Waline
