module.exports = window.echarts
