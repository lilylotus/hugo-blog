module.exports = window.twikoo
