module.exports = window.Artalk
