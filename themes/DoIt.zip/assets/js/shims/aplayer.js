module.exports = window.APlayer
